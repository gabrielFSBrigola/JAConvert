package software;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.InputStreamReader;
import java.time.Duration;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.google.gson.Gson;

public class conteiner {
	
	public static String absolut_path;
	public static String image_name;
	public static String image_format;
	public static String output_path;
	
	public conteiner(JFrame Win) {
		JPanel conte = new JPanel();
		conte.setLayout(null);
		conte.setBounds(0, 0, Win.getSize().width,Win.getSize().height);
		Win.add(conte);
		
		JLabel Piu_lb = new JLabel();
		Piu_lb.setText("Image Path");
		Piu_lb.setBounds(10, 10, 100, 20);
		conte.add(Piu_lb);
		
		JLabel NO_lb = new JLabel();
		NO_lb.setText("Image Name");
		NO_lb.setBounds(10, 60, 100, 20);
		conte.add(NO_lb);
		
		JLabel FO_lb = new JLabel();
		FO_lb.setText("Format Image");
		FO_lb.setBounds(10, 120, 100, 20);
		conte.add(FO_lb);
		
		JLabel SF_lb = new JLabel();
		SF_lb.setText("Output Path");
		SF_lb.setBounds(10, 170, 100, 20);
		conte.add(SF_lb);
		
		JTextField Piu_tf = new JTextField();
		Piu_tf.setBounds(10, 30, 100, 20);
		conte.add(Piu_tf);
		
		JTextField NO_tf = new JTextField();
		NO_tf.setBounds(10, 80, 100, 20);
		conte.add(NO_tf);
		
		
		
		JTextField FO_tf = new JTextField();
		FO_tf.setBounds(10, 140, 100, 20);
		conte.add(FO_tf);
		
		
		JTextField SF_tf = new JTextField();
		SF_tf.setBounds(10, 190, 100, 20);
		conte.add(SF_tf);
		
		JButton B = new JButton();
		B.setBounds(120, 30, 100, 20);
		B.setText("Search");
		B.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("Hello World!");
				JFileChooser FC = new JFileChooser();
				
				FC.setFileSelectionMode(JFileChooser.FILES_ONLY);
				
				int value_return = FC.showOpenDialog(null);
				
				if(value_return == JFileChooser.APPROVE_OPTION) {
					//System.out.println(FC.getSelectedFile().getAbsolutePath());
					Piu_tf.setText(FC.getSelectedFile().getAbsolutePath());
				}else {
					JOptionPane avisos = new JOptionPane();
					avisos.showMessageDialog(null, "Ação cancelada!");
				}
				
			}
		});
		conte.add(B);

		JButton converter_btn = new JButton();
		converter_btn.setBounds(10, 225, 100, 20);
		converter_btn.setText("Convert");
		converter_btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(NO_tf.getText().isEmpty() || FO_tf.getText().isEmpty() || Piu_tf.getText().isEmpty() || SF_tf.getText().isEmpty()) {
					JOptionPane aviso = new JOptionPane();
					aviso.showMessageDialog(null, "As caixas estão vazias!");
				}else {
					image_name = NO_tf.getText();
					absolut_path = Piu_tf.getText();
					image_format = FO_tf.getText();
					output_path = SF_tf.getText();
				}
				Gson gson = new Gson();
				data_save ds = new data_save(image_name,absolut_path,image_format,output_path);
				
				String json = gson.toJson(ds);
				
				try (FileWriter writer = new FileWriter("data.json")){
					writer.write(json);
				} catch (Exception e2) {
					e2.printStackTrace();
					JOptionPane aviso = new JOptionPane();
					aviso.showMessageDialog(null, "Algo deu errado:" + e2);
				}
				
				new Thread(()->{
					try {
						Thread.sleep(1);
						ProcessBuilder builder = new ProcessBuilder("core.exe");
						builder.redirectErrorStream(true);
						Process process = builder.start();
						
						BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						
						String linha;
						while((linha = reader.readLine()) != null) {
							System.out.println(linha);
						}
						int exitCode = process.waitFor();
						JOptionPane aviso = new JOptionPane();
						aviso.showMessageDialog(null, exitCode);
						System.out.println("Processo finalizado com código: " + exitCode);
						
						
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}).start();
				
			}
		});
		conte.add(converter_btn);
		
		JLabel autor_cradits = new JLabel();
		autor_cradits.setText("Feito por: GFSBR");
		autor_cradits.setBounds(150, 235, 100, 20);
		conte.add(autor_cradits);
		
		
	}
}
