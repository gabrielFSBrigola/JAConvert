package software;

public class data_save {
	private String name;
	private String image_path;
	private String format;
	private String image_output;
	
	public data_save(String name, String image_path, String format, String image_output) {
		this.name = name;
		this.image_path = image_path;
		this.format = format;
		this.image_output = image_output;
	}
}
