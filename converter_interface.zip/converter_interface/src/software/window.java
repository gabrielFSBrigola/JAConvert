package software;

import javax.swing.*;

public class window {
	public window() {
		JFrame win = new JFrame();
		win.setTitle("JAConvert");
		win.setSize(270,300);
		win.setLayout(null);
		win.setResizable(false);
		win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		conteiner Conteiner = new conteiner(win);
		
		win.setVisible(true);
	}
	
	
}
